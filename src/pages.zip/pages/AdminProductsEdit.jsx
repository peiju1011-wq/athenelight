import { useParams } from "react-router-dom";
import lightsData from "../data/lightsData";

export default function AdminProductsEdit(){

  const { slug } = useParams();

  const product = lightsData.find(
    item => item.slug === slug
  );

  if(!product){
    return <div>Product not found</div>;
  }

  return(

    <main className="p-10">

      <h1 className="text-3xl mb-10">
        Edit Product
      </h1>

      <div className="space-y-6">

        <input
          defaultValue={product.title?.zh}
          className="border p-3 w-full"
        />

        <input
          defaultValue={product.slug}
          className="border p-3 w-full"
        />

      </div>

    </main>

  );

}