import lightsData from "../data/lightsData";
import { Link } from "react-router-dom";

export default function AdminProducts(){

  return(

    <main className="p-10">

      <h1 className="text-3xl mb-10">
        Product Admin
      </h1>
      

      <div className="space-y-4">

        {lightsData.map(item => (

          <div
            key={item.id}
            className="border p-4 rounded"
          >

            <p>{item.title?.zh}</p>

            <p>{item.slug}</p>

      <Link
  to={`/admin/products/${item.slug}`}
>
  EDIT
</Link>

          </div>

          

        ))}

        

      </div>




    </main>
  );
}