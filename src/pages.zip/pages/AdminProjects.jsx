export default function AdminProjects(){

  return(

    <main className="p-10">

      <h1 className="text-3xl">
        Projects Admin
      </h1>

    </main>

  );
}